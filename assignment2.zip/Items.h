#ifndef ITEMS_H
#define ITEMS_H

using namespace std;

#include<vector>
#include <iostream>
#include <sstream>
#include <string>
#include <fstream>

class Items{
private:
	string ID;
	string Title;
	string Type;
	string Loan_type;
	int Stock;
	double Fee;
	string Genre;
	string Status;
public:
    //Getter
    string getID();
    string getTitle();
    string getType();
    string getLoantype();
    int getStock();
    double getFee();
    string getGenre();
    string getStatus();

    //Setter
    void setId(string ID);
    void setTitle(string title);
    void setType(string type);
    void setLoanType(string loan_type);
    void setStock(int stock);
    void setFee(double fee);
    void setGenre(string genre);
    void setStatus(string status);
    void setAll(string ID, string Title, string Type, string loan_type, int stock, double fee, string genre);
};

#endif