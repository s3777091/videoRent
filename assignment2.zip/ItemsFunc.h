#ifndef ITEMSFUNC_H
#define ITEMSFUNC_H

#include "RentalStores.h"
class ItemsFunc{
public:
	static void AddItem();
	static void ListItems();
	static void ListOutofStock();
	static void RentItem();
	static void ReturnItem();
	static void searchItemID();
	static void searchItemTitle();
	static void PrintItems();
};

#endif