// assignment2.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include "ItemsFunc.h"


RentalStore store;
int main(){
	static string itemfile = "items.txt";
    int choose;
    bool quit = false;
    //RentalStore::loadItems();
    do {
        cout << "====================================" << endl;
        cout << "Welcome to Genie's video store!" << endl;
        cout << "How can we help you? Please input an option." << endl;
        cout << "1. I'd like to add new item, update or delete an existing item" << endl;
        cout << "2. I'd like to add new customer or update an existing customer" << endl;
        cout << "3. I'd like to promote an existing customer" << endl;
        cout << "4. I'd like to rent an item" << endl;
        cout << "5. I'd like to return an item" << endl;
        cout << "6. I'd like to display all items" << endl;
        cout << "7. I'd like to display out-of-stock item" << endl;
        cout << "8. I'd like to display all customers" << endl;
        cout << "9. I'd like to display group of customers" << endl;
        cout << "10. I'd like to search items or customers" << endl;
        cout << "11. Please type 'Exit' whenever to end the program" << endl;
        cout << "Please input an option: ";
        cin >> choose;
        cout << "====================================" << endl;
        switch (choose) {
        case 1:
            ItemsFunc::AddItem();
            break;
        /*case 2:
            customer_check();
            break;
        case 3:
            CusFunc::Promote_Customer(customer, list_customer);
            break;*/
        case 4:
            ItemsFunc::RentItem();
            break;
        case 5:
            ItemsFunc::ReturnItem();
            break;
        case 6:
            ItemsFunc::ListItems();
            break;
        case 7:
            ItemsFunc::ListOutofStock();
            break;
        /*case 8:
            CustomerList::PrintListAllCustomer(list_customer);
            break;
        case 9:
            CusFunc::Display_customer_in_type(vst);
            break;*/
        case 10:
            ItemsFunc::searchItemID();
            break;
        case 11:
            ItemsFunc::PrintItems();
            cout << "S3777091 - HUYNH DAC TAN DAT " << endl;
            cout << "S3915177 - TRINH VAN MINH DUC" << endl;
            quit = true;
            break;
        default:
            cout << "invalid selection" << endl;
            break;
        }
    } while (!quit);
}

