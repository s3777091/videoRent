#include "RentalStores.h"

void RentalStore::loadItems() {
	Items Itm;
	string str;
	ifstream inFile("items.txt");
	if (!inFile) {
		cerr << "Error loading file!" << endl;
		return;
	}
	else
		while (getline(inFile, str)) {
			size_t i = str.find(",");
			Itm.setId(str.substr(0, i));
			str = str.substr(i + 1);
			i = str.find(",");
			Itm.setTitle(str.substr(0, i));
			str = str.substr(i + 1);
			i = str.find(",");
			Itm.setType(str.substr(0, i));
			str = str.substr(i + 1);
			i = str.find(",");
			Itm.setLoanType(str.substr(0, i));
			str = str.substr(i + 1);
			i = str.find(",");
			Itm.setStock(stoi(str.substr(0, i)));
			str = str.substr(i + 1);
			i = str.find(",");
			Itm.setFee(stod(str.substr(0, i)));
			Itm.setGenre(str.substr(i + 1));
		}	
	inFile.close();
}

