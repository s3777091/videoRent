#include "ItemsFunc.h"
extern RentalStore store;
bool isInt(const string& val) {
	const char* p = val.c_str();
	if ((*p) == '+')p++;
	while ((*p) != '\0') {
		if ((*p) < '0' || (*p) > '9')
			return false;
		p++;
	}
	return true;
}

bool isDouble(const string& val) {
	const char* p = val.c_str();
	int dot_counter = 0;
	if ((*p) == '+' || (*p) == '-')p++;
	while ((*p) != '\0') {
		if ((*p) == '.') {
			dot_counter++;
			if (dot_counter > 1)
				return false;
		}
		else if ((*p) < '0' || (*p) > '9')
			return false;
		p++;
	}
	return true;
}

void ItemsFunc::AddItem() {
	Items NewItm;
	string id, title, type, loan_type, stock, fee, genre;
	cout << "Please input new item ID: " << endl;
	cin >> id;
	for (size_t i = 0;i < store.ItemArray.size(); i++) {
		if (store.ItemArray[i].getID() == id) {
			cout << "This ID already exist." << endl;
			return;
		}
	}
	cout << "Please input item title: " << endl;
	cin >> title;

	cout << "Please input item type (Record/DVD/Game): " << endl;
	while (1) {
		cin >> type;
		if (type == "Record" || type == "DVD" || type == "Game")
			break;
		cout << "Please input a correct item type:" << endl;
	}

	cout << "Please input loan type (2-day/1-week): " << endl;
	cin >> loan_type;

	cout << "Please input item stock: " << endl;
	while (1) {
		cin >> stock;
		if (isInt(stock))
			break;
		cout << "Please input an integer for item stock: " << endl;
	}
	cout << "Please input item fee: " << endl;
	while (1) {
		cin >> fee;
		if (isDouble(fee))
			break;
		cout << "Please input a number for item fee: " << endl;
	}
	if (type == "Record" || type == "DVD") {
		NewItm.setAll(id, title, type, loan_type, stoi(stock), stod(fee), genre);
	}
	else {
		NewItm.setId(id);
		NewItm.setTitle(title);
		NewItm.setType(type);
		NewItm.setLoanType(loan_type);
		NewItm.setStock(stoi(stock));
		NewItm.setFee(stod(fee));
	}
	store.ItemArray.push_back(NewItm); //add item to ItemArray
}

void ItemsFunc::ListItems(){
	cout << "List of all the items: " << endl;
	for (size_t i = 0;i < store.ItemArray.size(); i++) {
		if (store.ItemArray[i].getType() == "Game") {
			cout << store.ItemArray[i].getID() << "," << store.ItemArray[i].getTitle() << ',' << store.ItemArray[i].getType()
				<< ',' << store.ItemArray[i].getLoantype() << ',' << store.ItemArray[i].getStock() << ',' << store.ItemArray[i].getFee()
				<< endl;
		}
		else
			cout << store.ItemArray[i].getID() << "," << store.ItemArray[i].getTitle() << ',' << store.ItemArray[i].getType()
			<< ',' << store.ItemArray[i].getLoantype() << ',' << store.ItemArray[i].getStock() << ',' << store.ItemArray[i].getFee()
			<< store.ItemArray[i].getGenre() << endl;
	}
}

void ItemsFunc::ListOutofStock() {
	cout << "List of out of stock items: " << endl;
	for (size_t i = 0; i< store.ItemArray.size(); i++) {
		if (store.ItemArray[i].getStock() == '0') {
			cout << store.ItemArray[i].getID() << "," << store.ItemArray[i].getTitle() << ',' << store.ItemArray[i].getType()
				<< ',' << store.ItemArray[i].getLoantype() << ',' << store.ItemArray[i].getStock() << ',' << store.ItemArray[i].getFee()
				<< ',' << store.ItemArray[i].getGenre() << endl;
			return;
		}
	}
}

void ItemsFunc::RentItem() {
	string item;
	int newstock;
	cout << "Please input the ID of the rented item:" << endl;
	cin >> item;
	for (size_t i = 0; i < store.ItemArray.size(); i++) {
		if (store.ItemArray[i].getID() == item) {
			if (store.ItemArray[i].getStock() == '0') {
				cout << "Item not available." << endl;
				return;
			}
			else {
				newstock = store.ItemArray[i].getStock() - 1;
				store.ItemArray[i].setStock(newstock);
				return;
			}
		}
	}
}

void ItemsFunc::ReturnItem() {
	string item;
	int newstock;
	cout << "Please input the ID of the rented item:" << endl;
	cin >> item;
	for (size_t i = 0;i < store.ItemArray.size(); i++) {
		if (store.ItemArray[i].getID() == item) {
			newstock = store.ItemArray[i].getStock() + 1;
			store.ItemArray[i].setStock(newstock);
			return;
		}
	}
}

void ItemsFunc::searchItemID() {
	string itemID;
	cout << "Please input the ID of the item:" << endl;
	cin >> itemID;
	for (size_t i = 0;i < store.ItemArray.size(); i++) {
		if (store.ItemArray[i].getID() == itemID) {
			cout << store.ItemArray[i].getID() << "," << store.ItemArray[i].getTitle() << ',' << store.ItemArray[i].getType()
				<< ',' << store.ItemArray[i].getLoantype() << ',' << store.ItemArray[i].getStock() << ',' << store.ItemArray[i].getFee()
				<< ',' << store.ItemArray[i].getGenre() << endl;
			return;
		}
	}
}

void ItemsFunc::searchItemTitle() {
	string itemTitle;
	cout << "Please input the Title of the item:" << endl;
	cin >> itemTitle;
	for (size_t i = 0; i< store.ItemArray.size(); i++) {
		if (store.ItemArray[i].getID() == itemTitle) {
			cout << store.ItemArray[i].getID() << "," << store.ItemArray[i].getTitle() << ',' << store.ItemArray[i].getType()
				<< ',' << store.ItemArray[i].getLoantype() << ',' << store.ItemArray[i].getStock() << ',' << store.ItemArray[i].getFee()
				<< ',' << store.ItemArray[i].getGenre() << endl;
			return;
		}
	}
	cout << "Item not found" << endl;
}

void ItemsFunc::PrintItems() {
	ofstream outFile;
	outFile.open("items.txt");
	if (!outFile) {
		cerr << "Error opening file" << endl;
		return;
	}
	for (size_t i = 0; i < store.ItemArray.size(); i++) {
		outFile << store.ItemArray[i].getID() << "," << store.ItemArray[i].getTitle() << ',' << store.ItemArray[i].getType()
			<< ',' << store.ItemArray[i].getLoantype() << ',' << store.ItemArray[i].getStock() << ',' << store.ItemArray[i].getFee()
			<< ',' << store.ItemArray[i].getGenre() << endl;
	}
	outFile.close();
}