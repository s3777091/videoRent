#include "Items.h"

string Items::getID() { return this->ID; }
string Items::getTitle() { return this->Title; }
string Items::getType() { return this->Type; }
string Items::getLoantype() { return this->Loan_type; }
int Items::getStock() { return this->Stock; }
double Items::getFee() { return this->Fee; }
string Items::getGenre() { return this->Genre; }
string Items::getStatus() { return this->Status; }

//Setter
void Items::setId(string ID) { this->ID = ID; }
void Items::setTitle(string title) { this->Title = title; }
void Items::setType(string type) { this->Type = type; }
void Items::setLoanType(string loan_type) { this->Loan_type = loan_type; }
void Items::setStock(int stock) { this->Stock = stock; }
void Items::setFee(double fee) { this->Fee = fee; }
void Items::setGenre(string genre) { this->Genre = genre; }
void Items::setStatus(string status) { this->Status = status; }
void Items::setAll(string ID, string Title, string Type, string loan_type, int stock, double fee, string genre) {
	this->ID = ID;
	this->Title = Title;
	this->Type = Type;
	this->Loan_type = loan_type;
	this->Stock = stock;
	this->Fee = fee;
	this->Genre = genre;
}
