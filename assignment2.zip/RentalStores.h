#ifndef RENTALSTORES_H
#define RENTALSTORES_H

#include "Items.h"


class RentalStore {
public:
	static void loadItems();
	vector<Items> ItemArray;
};


#endif